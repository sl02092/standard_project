"""
check_shortcut_collapse.py — Standalone shortcut-detection diagnostic.

WHY THIS EXISTS: tonight's LoRA fine-tuning run (step48) reported a headline
improvement (Baseline ADE 0.3809 -> Post-training ADE 0.1455) that turned out
to be a per-show positional-average shortcut, NOT genuine per-frame gaze
grounding -- caught only because that script happened to print per-show
prediction-vs-GT variance ratios alongside the headline number. Neither
step52_distillation_full_scale.py nor step52b_distillation_by_gaze_type.py
(the two distillation jobs currently running) have that same safeguard built
in. This script adds it, run AFTER either job finishes, against its already-
saved checkpoints -- no retraining needed.

WHAT IT CHECKS, per checkpoint (teacher-trained and GT-trained), per show:
  - pred_x_std / gt_x_std ratio: if predictions barely vary within a show
    while true gaze targets vary a lot (ratio << 1, roughly under ~0.3 is a
    red flag based on tonight's LoRA numbers, which were 0.03-0.11), that's
    the same collapse pattern -- the model output a near-constant per-show
    guess rather than reading each frame's actual content.
  - Trivial baseline comparison: predicting the GLOBAL mean (x,y) for every
    frame, completely blind to image content. If a checkpoint's ADE is close
    to or worse than this trivial blind baseline, the checkpoint result is
    NOT trustworthy regardless of what the headline ADE number says.

NOTE ON VAL-SET RECONSTRUCTION: step52_distillation_full_scale.py's
train/val split is NOT reproducibly reconstructable from outside the
original run (list(set(...)) before shuffle depends on Python's per-process
hash randomization -- see step52b's docstring for the full explanation).
Rather than risk a false "clean val set" assumption, this script instead
runs the diagnostic across a broad SAMPLE spanning many shows, with a
sample cap per show -- this is still a valid check for shortcut collapse
specifically (a model that memorized a per-show constant will show that
collapse whether or not a given frame was in its own training set), even
though it isn't a strict train/val-disjoint evaluation for absolute ADE
reporting purposes.

USAGE:
    python check_shortcut_collapse.py \
        --checkpoint experiment_results_full_targeted/model_teacher/best_model.pt \
        --labels /parallel_scratch/sl02092/standard_project/InternV3_GDino_Hybrid_Attempt_002/labels_hybrid_targeted.jsonl

Run once per checkpoint (model_teacher and model_gt, for each of the two
experiment output directories) -- four runs total gives a full picture.
"""

import os
import json
import math
import argparse
from collections import defaultdict

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from PIL import Image

try:
    import timm
except ImportError:
    raise ImportError("pip install timm")

IMG_SIZE = 224
HEAD_CROP_SIZE = 112
NORM_MEAN = [0.485, 0.456, 0.406]
NORM_STD = [0.229, 0.224, 0.225]
REF_W, REF_H = 1280, 720
MAX_PER_SHOW = 40  # cap frames per show, keeps this fast and prevents one
                    # very common show from dominating the diagnostic


# ── MODEL (must match Step52/Step52b's GazeStudent exactly, or the saved
# state_dict won't load) ─────────────────────────────────────────────────
class GazeStudent(nn.Module):
    def __init__(self, vit_model="vit_tiny_patch16_224"):
        super().__init__()
        self.encoder = timm.create_model(
            vit_model, pretrained=False, num_classes=0, global_pool="token",
        )
        feat_dim = self.encoder.num_features
        self.fusion = nn.Sequential(
            nn.Linear(feat_dim * 2, 256), nn.LayerNorm(256), nn.GELU(), nn.Dropout(0.2),
            nn.Linear(256, 128), nn.LayerNorm(128), nn.GELU(), nn.Dropout(0.1),
            nn.Linear(128, 2), nn.Sigmoid(),
        )

    def forward(self, scene, head):
        if head.shape[-1] != IMG_SIZE:
            head = F.interpolate(head, size=(IMG_SIZE, IMG_SIZE), mode="bilinear", align_corners=False)
        return self.fusion(torch.cat([self.encoder(scene), self.encoder(head)], dim=1))


# ── DATA (on-screen only, correct off-screen filter via gt_px_x/gt_px_y --
# same fix already established in step52b, not repeating the None-check bug) ──
def load_records(labels_path):
    records = []
    with open(labels_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            if rec.get("gt_px_x") == -1 or rec.get("gt_px_y") == -1:
                continue  # off-screen, excluded -- same rule as every other
                          # ADE number in this project
            if rec.get("gt_x") is None or rec.get("gt_y") is None:
                continue
            records.append(rec)
    return records


def sample_across_shows(records, max_per_show):
    by_show = defaultdict(list)
    for r in records:
        by_show[r.get("show", "unknown")].append(r)
    sampled = []
    for show, recs in by_show.items():
        sampled.extend(recs[:max_per_show])
    return sampled


def load_image_pair(rec):
    img = Image.open(rec["img_path"]).convert("RGB")
    w, h = img.size
    x1 = max(0, int(rec["head_x1"])); y1 = max(0, int(rec["head_y1"]))
    x2 = min(w, int(rec["head_x2"])); y2 = min(h, int(rec["head_y2"]))
    if x2 <= x1: x1, x2 = max(0, x1 - 1), min(w, x2 + 1)
    if y2 <= y1: y1, y2 = max(0, y1 - 1), min(h, y2 + 1)
    if x2 <= x1 or y2 <= y1:
        x1, y1, x2, y2 = 0, 0, w, h
    head_img = img.crop((x1, y1, x2, y2))
    return img, head_img, w, h


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True, help="path to best_model.pt")
    ap.add_argument("--labels", required=True, help="path to labels_hybrid_targeted.jsonl or equivalent")
    ap.add_argument("--vit_model", default="vit_tiny_patch16_224")
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[*] Device: {device}")
    print(f"[*] Checkpoint: {args.checkpoint}")
    print(f"[*] Labels: {args.labels}")

    print("[*] Loading model...")
    model = GazeStudent(vit_model=args.vit_model).to(device)
    ckpt = torch.load(args.checkpoint, map_location=device)
    state = ckpt.get("model_state", ckpt)  # tolerate either a raw state_dict
                                            # or the {"model_state": ...} wrapper
    model.load_state_dict(state)
    model.eval()
    print(f"    Loaded. (checkpoint reported val_ade={ckpt.get('val_ade', 'n/a')}, "
          f"epoch={ckpt.get('epoch', 'n/a')}, label_source={ckpt.get('label_source', 'n/a')})")

    print("[*] Loading records...")
    records = load_records(args.labels)
    print(f"    {len(records)} on-screen records total")
    sample = sample_across_shows(records, MAX_PER_SHOW)
    print(f"    Sampled {len(sample)} records across "
          f"{len(set(r.get('show','?') for r in sample))} shows "
          f"(cap {MAX_PER_SHOW}/show)")

    to_tensor = transforms.Compose([transforms.ToTensor(), transforms.Normalize(NORM_MEAN, NORM_STD)])
    resize_scene = transforms.Resize((IMG_SIZE, IMG_SIZE))
    resize_head = transforms.Resize((HEAD_CROP_SIZE, HEAD_CROP_SIZE))

    by_show = defaultdict(list)  # show -> list of (gt_x, gt_y, pred_x, pred_y)
    all_gt, all_pred = [], []

    print("[*] Running inference...")
    with torch.no_grad():
        for i, rec in enumerate(sample):
            try:
                img, head_img, w, h = load_image_pair(rec)
            except Exception as e:
                print(f"    [!] skip {rec.get('img_path')}: {e}")
                continue

            scene_t = to_tensor(resize_scene(img)).unsqueeze(0).to(device)
            head_t = to_tensor(resize_head(head_img)).unsqueeze(0).to(device)
            pred = model(scene_t, head_t)[0].cpu().tolist()

            gt_x, gt_y = float(rec["gt_x"]), float(rec["gt_y"])
            by_show[rec.get("show", "?")].append((gt_x, gt_y, pred[0], pred[1]))
            all_gt.append((gt_x, gt_y))
            all_pred.append((pred[0], pred[1]))

            if (i + 1) % 100 == 0:
                print(f"    {i+1}/{len(sample)}")

    # ── Trivial baseline: predict the GLOBAL mean for every frame ──────────
    mean_x = sum(g[0] for g in all_gt) / len(all_gt)
    mean_y = sum(g[1] for g in all_gt) / len(all_gt)
    trivial_dists = [math.sqrt((g[0]-mean_x)**2 + (g[1]-mean_y)**2) for g in all_gt]
    trivial_ade = sum(trivial_dists) / len(trivial_dists)

    # ── Model ADE ────────────────────────────────────────────────────────
    model_dists = [math.sqrt((g[0]-p[0])**2 + (g[1]-p[1])**2) for g, p in zip(all_gt, all_pred)]
    model_ade = sum(model_dists) / len(model_dists)

    print(f"\n{'='*70}")
    print("RESULTS")
    print(f"{'='*70}")
    print(f"[trivial-baseline] predicting global mean ({mean_x:.3f},{mean_y:.3f}) "
          f"for every frame -> ADE {trivial_ade:.4f}")
    print(f"[model]            ADE {model_ade:.4f}")
    if model_ade >= trivial_ade * 0.9:
        print("  [!] WARNING: model ADE is close to or worse than the trivial "
              "blind baseline. This result is NOT trustworthy as genuine "
              "per-frame spatial grounding -- treat as a collapsed/shortcut "
              "result regardless of how the headline number looks elsewhere.")
    else:
        print(f"  Model beats trivial baseline by {(trivial_ade - model_ade)/trivial_ade*100:.1f}% "
              f"-- necessary but not sufficient; check per-show variance below too.")

    print(f"\n[per-show variance check] pred_std should be comparable to gt_std "
          f"if the model is reading per-frame content, not guessing a per-show constant:")
    print(f"{'show':<25} {'n':<5} {'gt_x_std':<10} {'pred_x_std':<12} {'ratio':<8} flag")
    n_collapsed = 0
    n_shown = 0
    for show, vals in sorted(by_show.items()):
        if len(vals) < 3:
            continue
        n_shown += 1
        gt_xs = [v[0] for v in vals]
        pred_xs = [v[2] for v in vals]
        gt_mean = sum(gt_xs) / len(gt_xs)
        pred_mean = sum(pred_xs) / len(pred_xs)
        gt_std = (sum((x - gt_mean)**2 for x in gt_xs) / len(gt_xs)) ** 0.5
        pred_std = (sum((x - pred_mean)**2 for x in pred_xs) / len(pred_xs)) ** 0.5
        ratio = pred_std / gt_std if gt_std > 1e-6 else float("inf")
        flag = ""
        if ratio < 0.3:
            flag = "<-- LOW: possible shortcut"
            n_collapsed += 1
        print(f"{show:<25} {len(vals):<5} {gt_std:<10.4f} {pred_std:<12.4f} {ratio:<8.2f} {flag}")

    print(f"\n[summary] {n_collapsed}/{n_shown} shows show a low variance ratio (<0.3).")
    if n_collapsed > n_shown * 0.3:
        print("  [!] A substantial fraction of shows show the collapse pattern. "
              "Treat this checkpoint's headline ADE with real suspicion -- "
              "this is the same signature as tonight's LoRA shortcut result.")
    else:
        print("  Collapse pattern not widespread -- this checkpoint more likely "
              "reflects genuine per-frame grounding, though worth spot-checking "
              "a few individual predictions against their images directly too.")


if __name__ == "__main__":
    main()
